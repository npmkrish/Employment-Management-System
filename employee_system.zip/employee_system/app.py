from flask import Flask, render_template, request, redirect, url_for
from config import get_db_connection

app = Flask(__name__)

@app.route('/')
def index():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT e.emp_id, e.first_name, e.last_name, e.email, e.phone, e.salary,
               d.dept_name, j.job_title
        FROM employees e
        LEFT JOIN departments d ON e.dept_id = d.dept_id
        LEFT JOIN jobs j ON e.job_id = j.job_id
    """)
    employees = cursor.fetchall()
    conn.close()
    return render_template('index.html', employees=employees)

@app.route('/add', methods=['GET', 'POST'])
def add_employee():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM departments")
    departments = cursor.fetchall()
    cursor.execute("SELECT * FROM jobs")
    jobs = cursor.fetchall()

    if request.method == 'POST':
        data = (
            request.form['first_name'],
            request.form['last_name'],
            request.form['email'],
            request.form['phone'],
            request.form['hire_date'],
            request.form['job_id'],
            request.form['dept_id'],
            request.form['salary']
        )
        cursor.execute("""
            INSERT INTO employees (first_name, last_name, email, phone, hire_date, job_id, dept_id, salary)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
        """, data)
        conn.commit()
        conn.close()
        return redirect(url_for('index'))

    conn.close()
    return render_template('add_employee.html', departments=departments, jobs=jobs)

@app.route('/edit/<int:emp_id>', methods=['GET', 'POST'])
def edit_employee(emp_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM employees WHERE emp_id=%s", (emp_id,))
    emp = cursor.fetchone()

    cursor.execute("SELECT * FROM departments")
    departments = cursor.fetchall()
    cursor.execute("SELECT * FROM jobs")
    jobs = cursor.fetchall()

    if request.method == 'POST':
        data = (
            request.form['first_name'],
            request.form['last_name'],
            request.form['email'],
            request.form['phone'],
            request.form['hire_date'],
            request.form['job_id'],
            request.form['dept_id'],
            request.form['salary'],
            emp_id
        )
        cursor.execute("""
            UPDATE employees
            SET first_name=%s, last_name=%s, email=%s, phone=%s, hire_date=%s,
                job_id=%s, dept_id=%s, salary=%s
            WHERE emp_id=%s
        """, data)
        conn.commit()
        conn.close()
        return redirect(url_for('index'))

    conn.close()
    return render_template('edit_employee.html', emp=emp, departments=departments, jobs=jobs)

@app.route('/delete/<int:emp_id>')
def delete_employee(emp_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM employees WHERE emp_id=%s", (emp_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)

